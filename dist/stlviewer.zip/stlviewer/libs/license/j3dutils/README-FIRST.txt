The source code for the j3d-core-utils project is copyrighted code
that is licensed to individuals or companies who download or otherwise
access the code.

The copyright notice for this project is in COPYRIGHT.txt

The source code license information for this project is in LICENSE.txt

Additional information and license restrictions for third party source
code are found in the THIRDPARTY-LICENSE-*.txt files.

Instructions for building this project are in README-build.html
